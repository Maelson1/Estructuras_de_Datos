package main;

import java.io.File;
import java.util.*;

import graphsDSESIUCLM.Edge;
import graphsDSESIUCLM.Graph;
import graphsDSESIUCLM.TreeMapGraph;
import graphsDSESIUCLM.Vertex;

public class Main {

    // ======= RESULTADO DEL CAMINO (CAMINO + COSTE) =======
    static class PathResult {
        List<String> path;
        int cost;

        PathResult(List<String> path, int cost) {
            this.path = path;
            this.cost = cost;
        }
    }

    public static void main(String[] args) {

        Graph<DecoratedElement, Interaction<Integer>> graph =
                new TreeMapGraph<>();

        Map<String, Vertex<DecoratedElement>> nameToVertex = new HashMap<>();
        List<Vertex<DecoratedElement>> verticesByIndex = new ArrayList<>();

        // ================= VÉRTICES =================
        System.out.println("Cargando vértices...");
        try (Scanner sc = new Scanner(
                new File("starwars-full-interactions-allCharacters_vertices.csv"))) {

            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                if (line.isBlank()) continue;

                String[] p = line.split(",");
                String name = p[0].trim();

                DecoratedElement elem = new DecoratedElement(0, name);
                Vertex<DecoratedElement> v = graph.insertVertex(elem);

                nameToVertex.put(name, v);
                verticesByIndex.add(v);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        // ================= ARISTAS (NO DIRIGIDO) =================
        System.out.println("Cargando aristas...");
        int edgeCount = 0;

        try (Scanner sc = new Scanner(
                new File("starwars-full-interactions-allCharacters_aristas.csv"))) {

            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                if (line.isBlank()) continue;

                String[] p = line.split(",");
                int i = Integer.parseInt(p[0].trim());
                int j = Integer.parseInt(p[1].trim());
                int w = Integer.parseInt(p[2].trim());

                Vertex<DecoratedElement> v1 = verticesByIndex.get(i);
                Vertex<DecoratedElement> v2 = verticesByIndex.get(j);

                // IDs únicos + grafo no dirigido
                graph.insertEdge(v1, v2, new Interaction<>(edgeCount++, w));
                graph.insertEdge(v2, v1, new Interaction<>(edgeCount++, w));
            }

        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        System.out.println("Grafo creado");
        System.out.println("Número de vértices: " + verticesByIndex.size());
        System.out.println("Número de aristas: " + edgeCount);

        // ================= INPUT =================
        Scanner in = new Scanner(System.in);

        System.out.print("Introduce personaje origen: ");
        String oName = in.nextLine().trim();

        System.out.print("Introduce personaje destino: ");
        String dName = in.nextLine().trim();

        Vertex<DecoratedElement> origen = nameToVertex.get(oName);
        Vertex<DecoratedElement> destino = nameToVertex.get(dName);

        if (origen == null || destino == null) {
            System.out.println("Personaje no existe");
            return;
        }

        // ================= DIJKSTRA =================
        PathResult result = shortestPath(graph, origen, destino);

        System.out.println("\nSecuencia más corta:");
        if (result.path.isEmpty()) {
            System.out.println("No existe un camino entre estos personajes.");
        } else {
            System.out.println(String.join(" → ", result.path));
            System.out.println("Coste total: " + result.cost);
        }
    }

    // ================= DIJKSTRA =================
    private static PathResult shortestPath(
            Graph<DecoratedElement, Interaction<Integer>> graph,
            Vertex<DecoratedElement> origen,
            Vertex<DecoratedElement> destino) {

        Map<Vertex<DecoratedElement>, Integer> dist = new HashMap<>();
        Map<Vertex<DecoratedElement>, Vertex<DecoratedElement>> prev = new HashMap<>();

        PriorityQueue<Vertex<DecoratedElement>> pq =
                new PriorityQueue<>(Comparator.comparingInt(dist::get));

        // Inicializar distancias
        Iterator<Vertex<DecoratedElement>> itV = graph.getVertices();
        while (itV.hasNext()) {
            dist.put(itV.next(), Integer.MAX_VALUE);
        }

        dist.put(origen, 0);
        pq.add(origen);

        while (!pq.isEmpty()) {
            Vertex<DecoratedElement> u = pq.poll();
            if (u.equals(destino)) break;

            Iterator<Edge<Interaction<Integer>>> itE =
                    graph.incidentEdges(u);

            while (itE.hasNext()) {
                Edge<Interaction<Integer>> e = itE.next();
                Vertex<DecoratedElement> v = graph.opposite(u, e);

                int alt = dist.get(u) + e.getElement().getInteraction();
                if (alt < dist.get(v)) {
                    dist.put(v, alt);
                    prev.put(v, u);
                    pq.add(v);
                }
            }
        }

        if (!prev.containsKey(destino) && !origen.equals(destino)) {
            return new PathResult(Collections.emptyList(), -1);
        }

        List<String> path = new ArrayList<>();
        for (Vertex<DecoratedElement> v = destino; v != null; v = prev.get(v)) {
            path.add(v.getElement().getName());
        }

        Collections.reverse(path);
        return new PathResult(path, dist.get(destino));
    }
}
