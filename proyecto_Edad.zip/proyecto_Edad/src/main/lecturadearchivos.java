package main;

import java.io.File;
import java.util.*;

import graphsDSESIUCLM.Graph;
import graphsDSESIUCLM.Vertex;

public class lecturadearchivos {

    // ================== VÉRTICES ==================
    public static List<Vertex<DecoratedElement>> leerArchivoVertices(
            Graph<DecoratedElement, Interaction<Integer>> g,
            Map<String, Vertex<DecoratedElement>> nameToVertex) {

        List<Vertex<DecoratedElement>> verticesByIndex = new ArrayList<>();

        File archivo = new File("src/starwars-full-interactions-allCharacters_vertices.csv");

        try (Scanner sc = new Scanner(archivo)) {

            while (sc.hasNextLine()) {
                String linea = sc.nextLine().trim();
                if (linea.isEmpty()) continue;

                String[] parts = linea.split(",");
                String nombre = parts[0].trim();

                DecoratedElement elem = new DecoratedElement(0, nombre);
                Vertex<DecoratedElement> v = g.insertVertex(elem);

                nameToVertex.put(nombre, v);
                verticesByIndex.add(v); // ORDEN = ÍNDICE
            }

        } catch (Exception e) {
            System.out.println("Error leyendo vértices: " + e.getMessage());
        }

        return verticesByIndex;
    }

    // ================== ARISTAS ==================
    public static void leerArchivoAristas(
            Graph<DecoratedElement, Interaction<Integer>> g,
            List<Vertex<DecoratedElement>> verticesByIndex) {

        File archivo = new File("src/starwars-full-interactions-allCharacters_aristas.csv");

        try (Scanner sc = new Scanner(archivo)) {

            while (sc.hasNextLine()) {
                String linea = sc.nextLine().trim();
                if (linea.isEmpty()) continue;

                String[] parts = linea.split(",");
                int i = Integer.parseInt(parts[0].trim());
                int j = Integer.parseInt(parts[1].trim());
                int peso = Integer.parseInt(parts[2].trim());

                Vertex<DecoratedElement> v1 = verticesByIndex.get(i);
                Vertex<DecoratedElement> v2 = verticesByIndex.get(j);

                g.insertEdge(v1, v2, new Interaction<Integer>(peso, peso));
            }

        } catch (Exception e) {
            System.out.println("Error leyendo aristas: " + e.getMessage());
        }
    }
}
