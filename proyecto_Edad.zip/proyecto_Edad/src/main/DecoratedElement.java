package main;

import graphsDSESIUCLM.Element;

public class DecoratedElement implements Element {

    private int id;
    private String name;

    public DecoratedElement(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // 🔴 TreeMapGraph usa ESTE ID (NO puede ser null)
    @Override
    public String getID() {
        return name;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }
}
