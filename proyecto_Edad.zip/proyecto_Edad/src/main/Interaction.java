package main;

import graphsDSESIUCLM.Element;

public class Interaction<T> implements Element {

    private T id;
    private Integer interaction;

    public Interaction(T id, Integer interaction) {
        this.id = id;
        this.interaction = interaction;
    }

    // 🔴 TreeMapGraph necesita ID ÚNICO y NO nulo
    @Override
    public String getID() {
        return String.valueOf(id);
    }

    public Integer getInteraction() {
        return interaction;
    }
}
